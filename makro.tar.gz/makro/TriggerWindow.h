#include <QPushButton>
#include <QComboBox>
#include <QLineEdit>

#include <KDialog>

class TriggerWindow : public QDialog
{
	Q_OBJECT

	public:
		TriggerWindow();

  private slots:
	void addTrigger( QString );
	void saveTrigger();

  private:
  	QComboBox *triggerSpecialKeys;
  	QComboBox *triggerKeys;
  	QComboBox *triggerMouseButtons;
  	QLineEdit *trigger;
};

