#!/bin/bash

mkdir build
cd backend
qmake
make
cp ./makrod ../
cd ..
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=`kde4-config --prefix` -DCMAKE_BUILD_TYPE=release
su -c "make install; chmod +x /usr/bin/makrod"