#include <QLineEdit>
#include <QSpinBox>
#include <QCheckBox>

#include <KDialog>

class CreateMacroWindow : public QDialog
{
	Q_OBJECT

	public:
		CreateMacroWindow();

  private slots:
  	void addMacro();

  private:
  	QLineEdit *macroName;
  	QCheckBox *checkKeyboard;
  	QCheckBox *checkMouse;
};

