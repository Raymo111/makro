#include <KApplication>
#include <KAboutData>
#include <KCmdLineArgs>

#include "MainWindow.h"

int main(int argc, char *argv[])
{

KAboutData aboutData( "kde4test", 0, ki18n("KDE4 Test Application"), "1.0", ki18n("This application is only intended as a small test"), KAboutData::License_GPL, ki18n("(c) 2008"), ki18n("Some text..."), "http://www.linuxgamerz.com/" );
KCmdLineArgs::init( argc, argv, &aboutData );

KApplication app;

  	MainWindow mainWindow;
    	mainWindow.show();

app.exec();
}