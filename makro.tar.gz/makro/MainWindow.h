#include <QListWidget>

#include <KMainWindow>

class MainWindow : public QMainWindow
{
	Q_OBJECT

	public:
		MainWindow();

	public slots:
		void initMacros();

	private slots:
		void newMacro();
  		void removeMacro();
  		void runMacro();

	private:
		QListWidget *macroList;
};

