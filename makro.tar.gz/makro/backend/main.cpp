#include <QApplication>
#include <QProcess>
#include <QDir>
#include <QtDebug>

int main( int argc, char *argv[] )
{
	QApplication app( argc, argv);

	QDir macroDir( QDir::homePath()+"/.config/macros" );
	QStringList macros = macroDir.entryList( QStringList() << "*.bind" );

	int count = 0;
	foreach( QString currentMacro, macros )
	{
		count++;
		QProcess bindProcess;
			bindProcess.start( "xbindkeys", QStringList() << "-f" << QDir::homePath()+"/.config/macros/"+currentMacro );
			if( bindProcess.waitForFinished() )
			{
				qDebug() << "Activating keybinds for" << currentMacro;
			}
	}

	if( count == macros.count() )
		return 1;

	return app.exec();
}