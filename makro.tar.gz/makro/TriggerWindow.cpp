#include <QVBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QMenu>
#include <QtDebug>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QSettings>

#include <KIcon>

#include "TriggerWindow.h"

TriggerWindow::TriggerWindow()
{
	QGridLayout *headerLayout = new QGridLayout;
		headerLayout->setRowMinimumHeight( 0, 32 );
		headerLayout->setColumnMinimumWidth( 0, 200 );

	QLabel *headerLabel = new QLabel( "<b>Select a trigger</b>" );
	QLabel *headerIcon = new QLabel;
		headerIcon->setPixmap( KIcon( "configure-shortcuts").pixmap( 22 ) );

	headerLayout->addWidget( headerLabel, 0, 0 );
	headerLayout->addWidget( headerIcon, 0, 1, Qt::AlignRight );

	QVBoxLayout *mainLayout = new QVBoxLayout( this );
	QHBoxLayout *triggerBreadcumbLayout = new QHBoxLayout;

	QLabel *information = new QLabel( "Select a combination of key(s)/mouse button(s) to use, which will trigger this macro." );
	trigger = new QLineEdit;
		trigger->setReadOnly( true );

	triggerSpecialKeys = new QComboBox;
		triggerSpecialKeys->addItems( QStringList() << "Special Keys" << "Ctrl" << "Alt" << "Shift" );
		triggerSpecialKeys->insertSeparator( 1 );

	triggerKeys = new QComboBox;
		triggerKeys->addItems( QStringList() << "Keys" << "A" << "B" << "C" << "D" << "E" << "F" << "G" << "H" << "I" << "J" << "K" << "L" << "M" << "N" << "O" << "P" << "Q" << "R" << "S" << "T" << "U" << "V" << "X" << "Y" << "Z" );
		triggerKeys->insertSeparator( 1 );

	triggerMouseButtons = new QComboBox;
		triggerMouseButtons->addItems( QStringList() << "Mouse Buttons" << "b:1" << "b:2" << "b:3" );
		triggerMouseButtons->insertSeparator( 1 );

	QPushButton *buttonOk = new QPushButton( "OK" );
		buttonOk->setIcon( KIcon( "dialog-ok" ) );

	triggerBreadcumbLayout->addWidget( triggerSpecialKeys );
	triggerBreadcumbLayout->addWidget( triggerKeys );
	triggerBreadcumbLayout->addWidget( triggerMouseButtons );
	triggerBreadcumbLayout->addStretch( 1 );
	triggerBreadcumbLayout->addWidget( buttonOk );

	mainLayout->addLayout( headerLayout );
	mainLayout->addWidget( information );
	mainLayout->addWidget( trigger );
	mainLayout->addLayout( triggerBreadcumbLayout );

	setWindowTitle( "Triggers" );
	setWindowIcon( KIcon( "configure-shortcuts" ) );

	connect( triggerSpecialKeys, SIGNAL( activated( const QString & ) ), this, SLOT( addTrigger( const QString & ) ) );
	connect( triggerKeys, SIGNAL( activated( const QString & ) ), this, SLOT( addTrigger( const QString & ) ) );
	connect( triggerMouseButtons, SIGNAL( activated( const QString & ) ), this, SLOT( addTrigger( const QString & ) ) );

	connect( buttonOk, SIGNAL( clicked() ), this, SLOT( saveTrigger() ) );
}

void TriggerWindow::addTrigger( QString key )
{
	if( ( key != "Special Keys" ) and ( key != "Keys" ) and ( key != "Mouse Buttons" ) )
	{
		if( trigger->text().length() > 0 )
			trigger->setText( trigger->text()+"+"+key );
		else
			trigger->setText( key );

		if( triggerSpecialKeys->currentText() != "Special Keys" )
			triggerSpecialKeys->setDisabled( true );

		if( triggerKeys->currentText() != "Keys" )
			triggerKeys->setDisabled( true );

		if( triggerMouseButtons->currentText() != "Mouse Buttons" )
			triggerMouseButtons->setDisabled( true );

		triggerSpecialKeys->setCurrentIndex( 0 );
		triggerKeys->setCurrentIndex( 0 );
		triggerMouseButtons->setCurrentIndex( 0 );
	}
}

void TriggerWindow::saveTrigger()
{
	QSettings generalConfig( "macros", "generalConfig" );;
	QFile macroTriggerFile( QDir::homePath()+"/.config/macros/"+generalConfig.value( "file" ).toString()+".bind" );
	if( macroTriggerFile.open( QIODevice::Append ) )
	{
		QTextStream macroTriggerStream( &macroTriggerFile );
			macroTriggerStream << trigger->text();
	}

	close();
}
