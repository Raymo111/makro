#include <QSettings>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QGroupBox>
#include <QMessageBox>
#include <QDir>
#include <QProcess>
#include <QtDebug>

#include <KIcon>

#include <unistd.h>

#include "CreateMacroWindow.h"
#include "TriggerWindow.h"

CreateMacroWindow::CreateMacroWindow()
{
	QVBoxLayout *mainLayout = new QVBoxLayout( this );
	QGroupBox *box = new QGroupBox( "Macro name" );
	QVBoxLayout *boxLayout = new QVBoxLayout( box );
	QGridLayout *headerLayout = new QGridLayout;
		headerLayout->setRowMinimumHeight( 0, 32 );
		headerLayout->setColumnMinimumWidth( 0, 200 );

	QLabel *headerLabel = new QLabel( "<b>Add new macro</b>" );
	QLabel *headerIcon = new QLabel;
		headerIcon->setPixmap( KIcon( "document-new").pixmap( 22 ) );

	headerLayout->addWidget( headerLabel, 0, 0 );
	headerLayout->addWidget( headerIcon, 0, 1, Qt::AlignRight );

	macroName = new QLineEdit;

	boxLayout->addWidget( macroName );

	checkKeyboard = new QCheckBox( "Capture keyboard" );
	checkMouse = new QCheckBox( "Capture mouse" );

	QPushButton *buttonAdd = new QPushButton;
		buttonAdd->setText( "Add" );
		buttonAdd->setIcon( KIcon( "document-new" ) );

	QWidget *spacer = new QWidget;
		spacer->setMinimumSize( 10, 10 );

	mainLayout->addLayout( headerLayout );
	mainLayout->addWidget( box );
	mainLayout->addWidget( checkKeyboard );
	mainLayout->addWidget( checkMouse );
	mainLayout->addWidget( spacer );
	mainLayout->addWidget( buttonAdd );

	setWindowTitle( "Add new macro" );
	setWindowIcon( KIcon( "document-new" ) );

	connect( buttonAdd, SIGNAL( clicked() ), this, SLOT( addMacro() ) );
}

void CreateMacroWindow::addMacro()
{
	QString file = macroName->text().replace( " ", "" );
	QSettings generalConfig( "macros", "generalConfig" );
		generalConfig.setValue( "file", file );

	QSettings macroConfig( "macros", file );
		macroConfig.setValue( "macroName", macroName->text() );
		macroConfig.sync();

	QFile macroTriggerFile( QDir::homePath()+"/.config/macros/"+file+".bind" );
	if( macroTriggerFile.open( QIODevice::WriteOnly ) )
	{
		QTextStream macroTriggerStream( &macroTriggerFile );
			macroTriggerStream << "\"cnee --replay -f "+QDir::homePath()+"/.config/macros/"+file+".xns\"\n";
	}

	QPushButton *recordButton = new QPushButton;
		recordButton->setText( "Record" );
		recordButton->setIcon( KIcon( "media-record" ) );

	QMessageBox *recordDialog = new QMessageBox;
		recordDialog->setTextFormat( Qt::RichText );
		recordDialog->setText( "You will now record your macro.<br><br>Depending on what settings you choosed, the macro will record events until your selected <i>\"event limit\"</i> is reached.<br><br>Press <b>Record</b> to start the recording" );
		recordDialog->setWindowTitle( "Recording" );
		recordDialog->setWindowIcon( KIcon( "media-record" ) );
		recordDialog->addButton( recordButton, QMessageBox::ApplyRole );
		recordDialog->exec();

		if( recordDialog->clickedButton() == recordButton )
		{
			QStringList arguments;
				arguments << "--record";
			if( checkKeyboard->checkState() == Qt::Checked )
				arguments << "--keyboard";

			if( checkMouse->checkState() == Qt::Checked )
				arguments << "--mouse";

			arguments << "-o" << QDir::homePath()+"/.config/macros/"+file+".xns";

			QProcess recordProcess;
				recordProcess.start( "cnee", arguments );
				if( recordProcess.waitForStarted( -1 ) )
				{
					recordButton->setText( "Done" );
					recordButton->setIcon( KIcon( "media-playback-stop" ) );
					recordDialog->exec();

					recordProcess.close();

					QPushButton *buttonYes = new QPushButton( "Yes" );
						buttonYes->setIcon( KIcon( "dialog-ok" ) );
	
					QPushButton *buttonNo = new QPushButton( "No" );
						buttonNo->setIcon( KIcon( "dialog-cancel" ) );

					QMessageBox *triggerQuestion = new QMessageBox;
						recordDialog->setTextFormat( Qt::RichText );
						triggerQuestion->setIconPixmap( KIcon( "dialog-information" ).pixmap( 48 ) );
						triggerQuestion->setText( "<b>Macro captured!</b><br>Do you want to set a trigger for this macro?" );
						triggerQuestion->setWindowTitle( "Question" );
						triggerQuestion->setWindowIcon( KIcon( "dialog-information" ) );
						triggerQuestion->addButton( buttonYes, QMessageBox::YesRole );
						triggerQuestion->addButton( buttonNo, QMessageBox::NoRole );
						triggerQuestion->exec();

					if( triggerQuestion->clickedButton() == buttonYes )
					{
						TriggerWindow triggerWindow;
							triggerWindow.exec();

						QProcess killMacroDaemon;
							killMacroDaemon.start( "killall", QStringList() << "makrod" );
							if( killMacroDaemon.waitForFinished() )
								killMacroDaemon.start( "killall", QStringList() << "xbindkeys" );
								if( killMacroDaemon.waitForFinished() ) { }
								
						QProcess startMacroDaemon;
							startMacroDaemon.execute( "makrod" );
					}
					close();
				}
		}
}
