#include <QVBoxLayout>
#include <QToolBar>
#include <QToolButton>
#include <QFile>
#include <QtDebug>
#include <QSettings>
#include <QDir>
#include <QProcess>

#include <KIcon>

#include "MainWindow.h"
#include "CreateMacroWindow.h"

MainWindow::MainWindow()
{
	QWidget *centralWidget = new QWidget;
	QVBoxLayout *mainLayout = new QVBoxLayout( centralWidget );

	QToolButton *buttonNew = new QToolButton;
		buttonNew->setText( "New" );
		buttonNew->setToolButtonStyle( Qt::ToolButtonTextUnderIcon );
		buttonNew->setIcon( KIcon( "document-new" ) );

	QToolButton *buttonRemove = new QToolButton;
		buttonRemove->setText( "Remove" );
		buttonRemove->setToolButtonStyle( Qt::ToolButtonTextUnderIcon );
		buttonRemove->setIcon( KIcon( "edit-delete" ) );

	QToolButton *buttonRun = new QToolButton;
		buttonRun->setText( "Run" );
		buttonRun->setToolButtonStyle( Qt::ToolButtonTextUnderIcon );
		buttonRun->setIcon( KIcon( "run-build" ) );

	QToolBar *toolBar = new QToolBar;
		toolBar->addWidget( buttonNew );
		toolBar->addWidget( buttonRemove );
		toolBar->addSeparator();
		toolBar->addWidget( buttonRun );

	macroList = new QListWidget;

	mainLayout->addWidget( toolBar );
	mainLayout->addWidget( macroList );

	setCentralWidget( centralWidget );
	setWindowTitle( "Makro" );
	setWindowIcon( KIcon( "configure-shortcuts" ) );

	connect( buttonNew, SIGNAL( clicked() ), this, SLOT( newMacro() ) );
	connect( buttonRemove, SIGNAL( clicked() ), this, SLOT( removeMacro() ) );
	connect( buttonRun, SIGNAL( clicked() ), this, SLOT( runMacro() ) );

	initMacros();
}

void MainWindow::initMacros()
{
	QDir macroDir( QDir::homePath()+"/.config/macros" );
	QStringList macros = macroDir.entryList( QStringList() << "*.conf" );

	foreach( QString currentMacro, macros )
	{
		currentMacro.chop( 5 );
		if( currentMacro != "generalConfig" )
		{
			QSettings macroSettings( "macros", currentMacro );
			macroList->addItem( macroSettings.value( "macroName" ).toString() );
		}
	}
}

void MainWindow::newMacro()
{
	CreateMacroWindow *createMacroWindow = new CreateMacroWindow();
		createMacroWindow->exec();

	macroList->clear();
	initMacros();
}

void MainWindow::removeMacro()
{
	if( macroList->count() > 0 )
	{
		QString file = macroList->currentItem()->text().replace( " ", "" );

		QFile::remove( QDir::homePath()+"/.config/macros/"+file+".xns" );
		QFile::remove( QDir::homePath()+"/.config/macros/"+file+".conf" );
		QFile::remove( QDir::homePath()+"/.config/macros/"+file+".bind" );

		macroList->takeItem( macroList->currentRow() );
	}
}

void MainWindow::runMacro()
{
	if( macroList->count() > 0 )
	{
		QString file = macroList->currentItem()->text().replace( " ", "" );
		QProcess runMacro;
			runMacro.start( "cnee", QStringList() << "--replay" << "-f" << QDir::homePath()+"/.config/macros/"+file+".xns" );
			if( runMacro.waitForFinished( -1 ) ) { }
	}
}
